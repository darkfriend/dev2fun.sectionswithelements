<?
$arModuleVersion = array(
	"VERSION" => "0.2.1",
	"VERSION_DATE" => "2015-06-14 17:12:31"
);
?>