<?
if(IsModuleInstalled('dev2fun.sectionswithelements')){
	$updater->CopyFiles("install/components/dev2fun/section.element.group", "components/dev2fun/section.element.group");
}
?>