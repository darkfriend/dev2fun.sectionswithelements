<?
/**
* 
* @author dev2fun (darkfriend)
* @copyright darkfriend
* @version 0.1.1
* 
*/
$MESS["IBLOCK_CACHE_FILTER"] = "Cache at installed filter";
$MESS["T_PROP_DESC_ALL"] = "All";
$MESS["T_IBLOCK_DESC_SETTINGS_SECTIONS"] = "Settings for sections";
$MESS["T_IBLOCK_DESC_SETTINGS_ELEMENTS"] = "Settings for items";
$MESS["T_IBLOCK_DESC_DEPTH"] = "Nesting level";
$MESS["T_IBLOCK_DESC_COUNT_SECTIONS"] = "Number of output sections";
$MESS["T_IBLOCK_SECTION_EMPTY_ELEMENTS"] = "Don't show the partitions without items";
$MESS["T_IBLOCK_SECTIONS_IBORD1"] = "Field for the first sorting sections";
$MESS["T_IBLOCK_SECTIONS_IBBY1"] = "Direction of the first sort sections";
$MESS["T_IBLOCK_SECTIONS_IBORD2"] = "Field for the second sorting sections";
$MESS["T_IBLOCK_SECTIONS_IBBY2"] = "Direction for the second sorting sections";
$MESS["T_IBLOCK_DESC_SECTION_PAGE_URL"] = "URL details page section (default from setting information block)";
$MESS["T_IBLOCK_DESC_ASC"] = "Ascending";
$MESS["T_IBLOCK_DESC_DESC"] = "Descending";
$MESS["T_IBLOCK_DESC_FID"] = "ID";
$MESS["T_IBLOCK_DESC_FNAME"] = "Title";
$MESS["T_IBLOCK_DESC_FACT"] = "First date of activity";
$MESS["T_IBLOCK_DESC_FSORT"] = "Sort";
$MESS["T_IBLOCK_DESC_FTSAMP"] = "Last modified date";
$MESS["T_IBLOCK_DESC_IBORD1"] = "Field for the first sort of news";
$MESS["T_IBLOCK_DESC_IBBY1"] = "Direction of the first sort news";
$MESS["T_IBLOCK_DESC_IBORD2"] = "Field for the second sort of news";
$MESS["T_IBLOCK_DESC_IBBY2"] = "Direction for the second sort of news";
$MESS["T_IBLOCK_DESC_LIST_ID"] = "Information block code";
$MESS["T_IBLOCK_DESC_LIST_TYPE"] = "Information block type (used only for testing)";
$MESS["T_IBLOCK_DESC_LIST_CONT"] = "Number of news on the page";
$MESS["T_IBLOCK_DESC_DETAIL_PAGE_URL"] = "URL page detailed view (default from setting information block)";
$MESS["T_IBLOCK_DESC_INCLUDE_IBLOCK_INTO_CHAIN"] = "Include information block in the chain navigation";
$MESS["T_IBLOCK_PROPERTY"] = "Properties";
$MESS["T_IBLOCK_FILTER"] = "Filter";
$MESS["IBLOCK_FIELD"] = "Fields";
$MESS["T_IBLOCK_DESC_ACTIVE_DATE_FORMAT"] = "Format of the show date";
$MESS["T_IBLOCK_DESC_PAGER_NEWS"] = "News";
$MESS["T_IBLOCK_DESC_PREVIEW_TRUNCATE_LEN"] = "Maximum length of the announcement for the output (only for text)";
$MESS["T_IBLOCK_DESC_HIDE_LINK_WHEN_NO_DETAIL"] = "Hide link if there is no detailed description";
$MESS["IBLOCK_SECTION_ID"] = "ID section";
$MESS["IBLOCK_SECTION_CODE"] = "Code section";
$MESS["T_IBLOCK_DESC_ADD_SECTIONS_CHAIN"] = "Include a section in the chain navigation";
$MESS["T_IBLOCK_DESC_CHECK_DATES"] = "Show only the currently active elements";
$MESS["CP_BNL_SET_STATUS_404"] = "Set status 404 if not found element or section";
$MESS["CP_BNL_CACHE_GROUPS"] = "Consider the rights of access";
$MESS["CP_BNL_INCLUDE_SUBSECTIONS"] = "Show items subkeys";
$MESS["CP_BNL_SET_BROWSER_TITLE"] = "Set the title of the browser window";
$MESS["CP_BNL_SET_META_KEYWORDS"] = "Set keywords page";
$MESS["CP_BNL_SET_META_DESCRIPTION"] = "Set page description";
?>