<?
/**
* 
* @author dev2fun (darkfriend)
* @copyright darkfriend
* @version 0.1.1
* 
*/
$MESS ['T_IBLOCK_DESC_LIST'] = "The list of sections with elements";
$MESS ['T_IBLOCK_DESC_LIST_DESC'] = "Grouped list of sections with elements from one information block.";
$MESS ['T_IBLOCK_DESC_CONTENT'] = "Working with content";
?>