<?
$MESS ['T_NEWS_NEWS_NA'] = "Section not found.";
$MESS ['IBLOCK_MODULE_NOT_INSTALLED'] = "Information blocks module is not installed";
?>