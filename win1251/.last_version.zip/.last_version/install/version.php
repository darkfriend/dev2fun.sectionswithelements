<?
$arModuleVersion = array(
	"VERSION" => "0.1.3",
	"VERSION_DATE" => "2014-12-09 15:00:00",
);
?>