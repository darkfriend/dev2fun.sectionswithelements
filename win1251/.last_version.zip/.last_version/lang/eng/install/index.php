<?
$MESS["MODULE_NAME"] = "Module for installation of the component \"Sections with elements\"";
$MESS["MODULE_DESCRIPTION"] = "This module installs a component that displays the sections and their elements, list, taking into account settings";
$MESS["STEP1"] = "Installing the module \"Sections with elements\"";
$MESS["UNSTEP1"] = "Uninstall module \"Sections with elements\"";
$MESS["INSTALL_LAST_MSG"] = "Now you can use the component \"Sections with elements\" in the visual editor.<br>Don't forget to reset the cache in the visual editor.<br>Enjoy using, command <a href='http://dev2fun.com'>dev2fun</a>";
$MESS["INSTALL_SUCCESS"] = 'The module installed successfully';
$MESS["UNINSTALL_SUCCESS"] = 'The module uninstalled successfully';
$MESS["MSG_NO_READABLE"] = 'Error! Could not read section #PATH#';
$MESS["MSG_NO_WRITABLE"] = 'Error! Could not make entry in section #PATH#';
?>